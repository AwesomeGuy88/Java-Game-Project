#!/bin/bash
#
# The purpose of this script is to produce the master_tanks  .jar artifact which can
# be run by runme.sh
# Let it be noted that this Prototype of Vidivox was developed on the UG4
# computers, and as such has specific dependancies on the systems there.
#
# A further list of dependancies can be found in the README file.

# You will need a manifest.txt file
# This will need to be located in the same folder as the src folder

#
# COMPILE SECTION
#

cd src

# These commands must start inside the src folder
/usr/lib/jvm/jdk8/bin/javac -cp . `find | grep .java$`

# Everything `find | grep .class$` `find | grep .css$` `find | grep .png$ is the filenames of what will be in your jar.
# Main.class Other.class .... image.png
# atm all .class files, .css files .png files and .mp4 files are included
/usr/lib/jvm/jdk8/bin/jar cvfm ../master_tanks.jar ../manifest.txt `find | grep .class$` `find | grep .png$` `find | grep .mp3$` `find | grep .wav$` `find | grep .ttf$` `find | grep .css$`
chmod 777 master_tanks.jar
cd ..
#
# RUN SECTION
#
#
# This cleans up class files, not required.
rm -f `find | grep .class$`

# This runs the jar
/usr/lib/jvm/jdk8/bin/java -jar master_tanks.jar
